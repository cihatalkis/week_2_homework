[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-f059dc9a6f8d3a56e377f745f24479a46679e63a5d9fe6f495e02850cd0d8118.svg)](https://classroom.github.com/online_ide?assignment_repo_id=5446943&assignment_repo_type=AssignmentRepo)
# Ödev 2: Rastgele Mesaj Panosu

Bu ödev içerisinde `posts.php`, `post.php` ve `functions.php` dosyalarında düzenleme yapmanız beklenmektedir. Yapılacak olan düzenlemeler ile ilgili bilgiler betik dosyalarında mevcut.

Ödevi kontrol ederken aşağıdaki adımları uygulayabilirsiniz:

- [localhost/posts.php](http://localhost/posts.php) adresini ziyaret ettiğinizde herhangi bir hata veya uyarı mesajı vermeden rastgele sayıda ve "random" arkaplanlarda yazı başlıkları, numaraları ve içerikleri listelenmeli.
- [localhost/post.php](http://localhost/post.php) adresini ziyaret ettiğinizde herhangi bir hata veya uyarı mesajı vermeden sizin tanımladığınız değerlerle yazı başlığı, numarası ve içeriği gelmeli.
- [localhost/functions.php](http://localhost/functions.php) adresini ziyaret ettiğinizde bu dosyayı direk çalıştıramayacağınıza dair bir metin gösterilmeli. Bunun dışında bir hata veya uyarı mesajı yer almamalıdır.

